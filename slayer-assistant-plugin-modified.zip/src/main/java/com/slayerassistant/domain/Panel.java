package com.slayerassistant.domain;

public enum Panel
{
    TASK_SEARCH,
    TASK_SELECTED
}
