package com.slayerassistant;

import com.google.inject.Binder;
import com.slayerassistant.domain.Icon;
import com.slayerassistant.modules.TaskServiceModule;
import com.slayerassistant.presentation.panels.MainPanel;
import lombok.extern.slf4j.Slf4j;
import net.runelite.client.plugins.Plugin;
import net.runelite.client.plugins.PluginDescriptor;
import net.runelite.client.ui.ClientToolbar;
import net.runelite.client.ui.NavigationButton;

import javax.inject.Inject;

@Slf4j
@PluginDescriptor(
	name = "Slayer Assistant",
	description = "Assists with slayer task information",
	tags = { "slay", "slayer", "assistant" }
)
public class SlayerAssistantPlugin extends Plugin
{
	@Inject
	private ClientToolbar clientToolbar;
	
	@Inject
	private MainPanel mainPanel;
	
	private NavigationButton navButton;

    @Override
	public void configure(Binder binder)
	{
		binder.install(new TaskServiceModule());
	}

	@Override
	protected void startUp()
	{
		injector.injectMembers(this);

		navButton = getNavButton();

		clientToolbar.addNavigation(navButton);
	}

	@Override
	protected void shutDown()
	{
		clientToolbar.removeNavigation(navButton);
		mainPanel.shutDown();
	}

	private NavigationButton getNavButton()
	{
		return NavigationButton.builder()
				.tooltip("Slayer Assistant")
				.icon(Icon.SLAYER_SKILL.getImage())
				.priority(10)
				.panel(mainPanel)
				.build();
	}
}


import com.google.gson.JsonObject;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import java.io.IOException;

public class SlayerAssistantPlugin extends Plugin {

    private final OkHttpClient httpClient = new OkHttpClient();

    // Fetch monster stats from the OSRS Wiki
    public JsonObject getMonsterStats(String monsterName) {
        HttpUrl url = HttpUrl.parse("https://oldschool.runescape.wiki/api.php")
                .newBuilder()
                .addQueryParameter("action", "query")
                .addQueryParameter("format", "json")
                .addQueryParameter("titles", monsterName)
                .addQueryParameter("prop", "info")
                .build();

        Request request = new Request.Builder().url(url).build();
        try (Response response = httpClient.newCall(request).execute()) {
            if (response.isSuccessful()) {
                String jsonData = response.body().string();
                return new com.google.gson.JsonParser().parse(jsonData).getAsJsonObject();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Display monster stats in the UI
    public void displayMonsterStats(String monsterName) {
        JsonObject monsterData = getMonsterStats(monsterName);
        if (monsterData != null) {
            String hitpoints = monsterData.get("hitpoints").getAsString();
            String attack = monsterData.get("attack").getAsString();
            String defense = monsterData.get("defense").getAsString();

            // Show the data in the plugin panel
            mainPanel.addInfoBox(new InfoBoxComponent(hitpoints, attack, defense));
        } else {
            log.error("No data found for " + monsterName);
        }
    }

    @Override
    protected void startUp() {
        // Example to test the function
        displayMonsterStats("TzHaar-Ket");
    }
}
